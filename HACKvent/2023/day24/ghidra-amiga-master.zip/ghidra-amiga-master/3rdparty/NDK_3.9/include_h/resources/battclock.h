#ifndef RESOURCES_BATTCLOCK_H
#define RESOURCES_BATTCLOCK_H 1
/*
**	$VER: battclock.h 36.4 (1.5.1990)
**	Includes Release 45.1
**
**	BattClock resource name strings.
**
**	(C) Copyright 1989-2001 Amiga, Inc.
**		All Rights Reserved
*/

#define BATTCLOCKNAME	"battclock.resource"

#endif /* RESOURCES_BATTCLOCK_H */
