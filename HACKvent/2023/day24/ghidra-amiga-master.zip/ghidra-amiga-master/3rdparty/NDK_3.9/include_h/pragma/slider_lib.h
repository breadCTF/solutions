#ifndef PRAGMA_SLIDER_H
#define PRAGMA_SLIDER_H

/*
**	$VER: slider_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_SLIDER_PRAGMAS_H
#include <pragmas/slider_pragmas.h>
#endif

#endif /* PRAGMA_SLIDER_H */
