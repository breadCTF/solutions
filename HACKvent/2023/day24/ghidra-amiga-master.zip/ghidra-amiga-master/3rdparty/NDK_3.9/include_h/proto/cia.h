#ifndef PROTO_CIA_H
#define PROTO_CIA_H

/*
**	$VER: cia.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Lattice `C' style prototype/pragma header file combo
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_CIA_PRAGMAS_H
#include <pragmas/cia_pragmas.h>
#endif

#ifndef EXEC_LIBRARIES_H
#include <exec/libraries.h>
#endif

#endif /* PROTO_CIA_H */
