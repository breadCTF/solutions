#ifndef RESOURCES_BATTMEM_H
#define RESOURCES_BATTMEM_H 1
/*
**	$VER: battmem.h 36.4 (1.5.1990)
**	Includes Release 45.1
**
**	BattMem resource name strings.
**
**	(C) Copyright 1989-2001 Amiga, Inc.
**		All Rights Reserved
*/

#define BATTMEMNAME	"battmem.resource"

#endif /* RESOURCES_BATTMEM_H */
