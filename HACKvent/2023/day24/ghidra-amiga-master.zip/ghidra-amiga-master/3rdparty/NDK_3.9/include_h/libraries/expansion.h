#ifndef LIBRARIES_EXPANSION_H
#define	LIBRARIES_EXPANSION_H
/*
**	$VER: expansion.h 36.7 (28.5.1990)
**	Includes Release 45.1
**
**	External definitions for expansion.library
**
**	(C) Copyright 1985-2001 Amiga, Inc.
**	    All Rights Reserved
*/

#define EXPANSIONNAME	"expansion.library"

/* flags for the AddDosNode() call */
#define ADNB_STARTPROC	0
#define ADNF_STARTPROC	(1L<<0)

#endif /* LIBRARIES_EXPANSION_H */
