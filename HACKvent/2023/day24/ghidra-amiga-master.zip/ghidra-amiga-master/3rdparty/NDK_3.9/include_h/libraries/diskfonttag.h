#ifndef  LIBRARIES_DISKFONTTAG_H
#define  LIBRARIES_DISKFONTTAG_H
/*
**	$VER: diskfonttag.h 10.1 (3.2.1992)
**	Includes Release 45.1
**
**	libraries/diskfonttag.h -- tag definitions for .otag files
**
**	(C) Copyright 1990 Robert R. Burns
**	    All Rights Reserved
*/

#ifndef	DISKFONT_DISKFONTTAG_H
#include <diskfont/diskfonttag.h>
#endif

#endif	 /* LIBRARIES_DISKFONTTAG_H */
