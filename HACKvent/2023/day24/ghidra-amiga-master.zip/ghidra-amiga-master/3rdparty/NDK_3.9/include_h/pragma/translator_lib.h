#ifndef PRAGMA_TRANSLATOR_H
#define PRAGMA_TRANSLATOR_H

/*
**	$VER: translator_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_TRANSLATOR_PRAGMAS_H
#include <pragmas/translator_pragmas.h>
#endif

#endif /* PRAGMA_TRANSLATOR_H */
