#ifndef PRAGMA_CARDRES_H
#define PRAGMA_CARDRES_H

/*
**	$VER: cardres_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_CARDRES_PRAGMAS_H
#include <pragmas/cardres_pragmas.h>
#endif

#endif /* PRAGMA_CARDRES_H */
