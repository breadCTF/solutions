#ifndef LIBRARIES_DOS_H
#define LIBRARIES_DOS_H
/*
**	$VER: dos.h 36.2 (12.7.1990)
**	Includes Release 45.1
**
**	Standard C header for AmigaDOS
**
**	(C) Copyright 1985-2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef DOS_DOS_H
#include <dos/dos.h>
#endif

#endif /* LIBRARIES_DOS_H */
