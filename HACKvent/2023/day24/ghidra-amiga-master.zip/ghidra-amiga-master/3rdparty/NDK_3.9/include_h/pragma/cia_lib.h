#ifndef PRAGMA_CIA_H
#define PRAGMA_CIA_H

/*
**	$VER: cia_lib.h 44.1 (1.11.1999)
**	Includes Release 45.1
**
**	Aztec `C' style pragma header file wrapper
**
**	(C) Copyright 2001 Amiga, Inc.
**	    All Rights Reserved
*/

#ifndef PRAGMAS_CIA_PRAGMAS_H
#include <pragmas/cia_pragmas.h>
#endif

#endif /* PRAGMA_CIA_H */
