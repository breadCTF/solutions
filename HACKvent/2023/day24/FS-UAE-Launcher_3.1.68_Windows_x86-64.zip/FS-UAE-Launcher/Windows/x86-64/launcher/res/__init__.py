# noinspection PyUnresolvedReferences
from launcher.i18n import gettext
